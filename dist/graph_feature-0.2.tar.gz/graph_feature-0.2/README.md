TODO:
1. TEST the update 
2. ensure that the package works as intended with the action.